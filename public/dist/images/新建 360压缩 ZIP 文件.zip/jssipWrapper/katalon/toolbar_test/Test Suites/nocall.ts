<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>nocall</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>0c855aa9-8906-45e7-b611-4e49564a1382</testSuiteGuid>
   <testCaseLink>
      <guid>8121bc87-e6a0-4e75-b61c-b2b90a561631</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f154771e-f0ed-46a7-90b1-f67eac17cdfd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/setting</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
