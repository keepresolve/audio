<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>right_label</name>
   <tag></tag>
   <elementGuidId>04167f47-15d5-4f9e-b50c-ffee842f8b8f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;PHONE-ENTRY-SETTING&quot;)/ul[1]/li[3]/span[2]/label[2][count(. | //label[(text() = ' 右 ' or . = ' 右 ')]) = count(//label[(text() = ' 右 ' or . = ' 右 ')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 右 </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;PHONE-ENTRY-SETTING&quot;)/ul[1]/li[3]/span[2]/label[2]</value>
   </webElementProperties>
</WebElementEntity>
