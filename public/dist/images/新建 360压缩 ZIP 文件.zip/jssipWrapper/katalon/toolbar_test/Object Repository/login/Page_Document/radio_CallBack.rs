<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>radio_CallBack</name>
   <tag></tag>
   <elementGuidId>83fb3bf9-b001-4f2b-bb09-6b7d85d508f8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;PHONE-ENTRY-LOGIN&quot;)/ul[1]/li[5]/label[3]/span[1][count(. | //span[(text() = ' 回拨话机' or . = ' 回拨话机')]) = count(//span[(text() = ' 回拨话机' or . = ' 回拨话机')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 回拨话机</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;PHONE-ENTRY-LOGIN&quot;)/ul[1]/li[5]/label[3]/span[1]</value>
   </webElementProperties>
</WebElementEntity>
